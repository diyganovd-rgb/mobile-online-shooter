package com.example.mobileonlineshooter

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class GameView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var playerX = 600f
    private var playerY = 400f
    private var hp = 100
    private var score = 0
    private var fireX = -1f
    private var fireY = -1f
    private var message = "ONLINE SHOOTER"

    init { paint.typeface = Typeface.DEFAULT_BOLD }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(28, 32, 40))

        paint.color = Color.rgb(48, 55, 66)
        for (x in 0..width step 80) c.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), paint)
        for (y in 0..height step 80) c.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), paint)

        paint.color = Color.rgb(70, 180, 110)
        c.drawCircle(playerX, playerY, 34f, paint)

        paint.color = Color.WHITE
        paint.textSize = 34f
        c.drawText(message, 30f, 45f, paint)
        c.drawText("HP: $hp", 30f, 88f, paint)
        c.drawText("KILLS: $score", 30f, 128f, paint)

        paint.color = Color.rgb(180, 180, 190)
        c.drawCircle(100f, height - 100f, 70f, paint)
        paint.color = Color.WHITE
        paint.textSize = 25f
        c.drawText("MOVE", 65f, height - 92f, paint)

        paint.color = Color.rgb(190, 70, 70)
        c.drawCircle(width - 110f, height - 110f, 85f, paint)
        paint.color = Color.WHITE
        paint.textSize = 25f
        c.drawText("FIRE", width - 145f, height - 102f, paint)

        if (fireX >= 0) {
            paint.color = Color.YELLOW
            c.drawCircle(fireX, fireY, 9f, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val x = e.x
                val y = e.y
                if (x > width - 220 && y > height - 210) {
                    fireX = x - 110
                    fireY = y - 110
                    score++
                    message = "ПОПАДАНИЕ! +1"
                } else if (x < 220 && y > height - 210) {
                    playerX = (playerX + (x - 100) / 5f).coerceIn(40f, width - 40f)
                    playerY = (playerY + (y - (height - 100)) / 5f).coerceIn(40f, height - 40f)
                    message = "ONLINE"
                }
                invalidate()
            }
        }
        return true
    }
}
